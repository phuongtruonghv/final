
<?php
session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Đăng nhập</title>
  <style>
    .button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
    }
	<style>
	table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
	}
</style>

</head>

<body style="font-size:100%;">
	<?php date_default_timezone_set('Asia/Ho_Chi_Minh'); ?>

  <center> <h1 style="color:SlateBlue;"> WELCOME TO H&P HOTEL!!!</h1>

	<div id="InputForm">
		<form>
		<p> Home page </p>
		</form>
	</div>
</center>
<img src= 'img_chania.jpg' alt="Flowers in Chania">


</body>
</html>
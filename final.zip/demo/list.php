<?php
session_start();
//tiến hành kiểm tra là người dùng đã đăng nhập hay chưa
//nếu chưa, chuyển hướng người dùng ra lại trang đăng nhập
if (!isset($_SESSION['username'])) {
	header('Location: index.php');
}
?>
<?php date_default_timezone_set('Asia/Ho_Chi_Minh'); ?>
<html>
<head>
	
	<meta charset="utf-8">
	<title>Thư viện TDT</title>
</head>
<body>
	Người dùng: <?php 
		$username = $_SESSION['username'];
		echo $username; echo "<br>";  ?>
	Đăng nhập thành công!!!
	<?php 
		$url = "http://localhost:8080/iBanking/rest/services/list/";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		$data = curl_exec($ch);
		curl_close($ch);
		$array = explode("/", $data);
		$number ="";
		foreach($array as $value){
			$number = $number.$value. "<br>";
		}
		$array1 = explode("?",$number);
		$number1 = "";
		foreach($array1 as $value){
			$number1 = $number1.$value. "<br>";
		}
		$txt1 = "Sách có thể mượn: ";
		echo "<h2>" . $txt1 . "</h2>";
		echo "$number1<br>"; 
	?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Mượn sách</title>
</head>

<body style="font-size:125%;">
	<?php date_default_timezone_set('Asia/Ho_Chi_Minh');
		$day_b = date('Y-m-d', time());
		$myDate = new DateTime($day_b);
		$myDate->modify("+30 days");
		$day_r = $myDate->format('Y-m-d'); ?>
	<h1>Đăng kí mượn sách</h1>
	<div id="InputForm">
		<form id="submitForm" method="POST">
			Mã sách:<br>
			<input type="text" class="form-control" id="bookid" name="bookid" /><br><br>
			<button id="submitBtn" type="submit" name= "borrow">Mượn</button>
			<button id="submitBtn2" type="submit" name= "exit">Đăng xuất</button>
		</form>
	</div>

	<?php
		if (isset($_POST["borrow"]))
		{
			$bookid = $_POST['bookid'];
			if ($bookid == "") {
					echo "bạn vui lòng nhập đầy đủ thông tin";
			}
			else{
				$url = "http://localhost:8080/iBanking/rest/services/borrow/";
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				$data = array('bookid'=>$_POST['bookid'], 'day_b'=>$day_b,'day_r'=>$myDate);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
				$output = curl_exec($ch);
				$info = curl_getinfo($ch);
				curl_close($ch);
				//Print the data out onto the page.
				if ($output == "true"){
						$url = "http://localhost:8080/iBanking/rest/services/bill/".$username."/".$_POST['bookid']."/".$day_b."/".$day_r;
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
						$data2 = array('username'=>$username,'bookid'=>$_POST['bookid'],'day_b'=>$day_b,'day_r'=>$day_r);
						curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data2));
						$output2 = curl_exec($ch);
						$info = curl_getinfo($ch);
						curl_close($ch);
						echo "$output2<br>";
						echo "Ngày mượn: $day_b <br>";
						echo "Ngày trả: $day_r <br>";
				}
				else {
						echo "Mã sách không tồn tại";
				}
			}
		}
		else if(isset($_POST["exit"]))
		{
			header('Location: index.php');
			session_destroy();
		}
		
	?>
</body>
</body>
</html>

<?php
session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Đăng nhập</title>
  <style>
    .button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
    }
	<style>
	table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
	}
</style>

</head>

<body style="font-size:100%;">
	<?php date_default_timezone_set('Asia/Ho_Chi_Minh'); ?>

  <center> <h1 style="color:SlateBlue;"> WELCOME TO InterContinental Saigon Hotel & Residences !!!</h1>

	<div id="InputForm">
	<p style="color:Tomato;"> Please choose your role..!!! </p>
		<form action="" method="post">
		Receptionist <input type="radio" name="role" value="recep">
		Administrator <input type="radio" name="role" value="admin">
		Customer <input type="radio" name="role" value="custom"><br>
		<button type="submit">OK</button>
		</form>
	</div>
</center>

</body>
<?php
	
	if(isset($_POST["role"])) {
		$role =  $_POST["role"];
		if ($role == "recep" || $role == "admin"){
			header('Location: login.php');
		}
		else if ($role == "custom") {
			header('Location: index.html');
		}
	}
	
?>
</html>

<?php
session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Login</title>
  <style>
  @import url(https://fonts.googleapis.com/css?family=Roboto:300);

.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
body {
  background: #76b852; /* fallback for old browsers */
  background: -webkit-linear-gradient(right, #76b852, #8DC26F);
  background: -moz-linear-gradient(right, #76b852, #8DC26F);
  background: -o-linear-gradient(right, #76b852, #8DC26F);
  background: linear-gradient(to left, #76b852, #8DC26F);
  font-family: "Roboto", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;      
}
    .button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
    }
	<style>
	table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
	}
</style>

</head>

<body style="font-size:125%;">
	<?php date_default_timezone_set('Asia/Ho_Chi_Minh'); ?>

  <h1>Vui lòng đăng nhập với vai trò admin hoặc tiếp tân!!!</h1>

  <div id="InputForm" class="login-page">
    <form id="signInForm" method="post" class="register-form">
      <p>
        Username: <input type="text" name="username" required />
      </p>

      <p>
        Password: <input type="password" name="password" required />
      </p>

      <button id="submitBtn" type="submit" class="button"> Login </button>
    </form>
	</div>
	
</body>
<?php
		if (isset($_POST['username']) && isset($_POST['password']))
		{
			// Send username/password to Tomcat server for authenticating
			  $ch = curl_init();
			  curl_setopt($ch, CURLOPT_URL, "http://localhost:8080/iBanking/rest/services/sign-in-secure-v2/");
			  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			  curl_setopt($ch, CURLOPT_POST, 1);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded')); // In Java: @Consumes(MediaType.APPLICATION_FORM_URLENCODED)

			  $data = array('username'=>$_POST['username'],'password'=>$_POST['password']);
			  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

			  $output = curl_exec($ch);
			  $info = curl_getinfo($ch);
			  curl_close($ch);

			//If the server returns TRUE, then print something
		  if($output == "true")
		  {
			$username = $_POST["username"];
			$password = $_POST["password"];
			echo "Login successfully<br>";
			//tiến hành lưu tên đăng nhập vào session để tiện xử lý sau này
			// Send username to Tomcat server to send login email confirmation
				$url = "http://localhost:8080/iBanking/rest/services/send-email/" . $_POST['username'];
				$ch_username = curl_init();
				curl_setopt($ch_username, CURLOPT_URL, $url);
				curl_setopt($ch_username, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch_username, CURLOPT_FOLLOWLOCATION, true);
				curl_exec($ch_username);
				curl_close($ch_username);
			$_SESSION['username'] = $username;
			 // Thực thi hành động sau khi lưu thông tin vào session
			 // ở đây mình tiến hành chuyển hướng trang web tới một trang gọi là index.php
			 header('Location: admin.php');
		  }
		  else
		  {
			echo "Tên đăng nhập/Mật khẩu sai! Vui lòng kiểm tra lại";
		  }
		}
	?>
	
</html>
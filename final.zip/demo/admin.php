<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
div.container {
    width: 100%;
    border: 1px solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 160px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
    padding: 0;
}
   
nav ul a {
    text-decoration: none;
}

article {
    margin-left: 170px;
    border-left: 1px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body>

<div class="container">

<header>
   <h1>Administrator Management</h1>
</header>
<div id="menu">
  <ul>
    <li><a href="#">Trang chủ</a></li>
    <li><a href="#">Tin tức</a>
      <ul class="sub-menu">
        <li><a href="#">WordPress</a></li>
        <li><a href="#"><a href="https://thachpham.com/category/seo" data-wpel-link="internal">SEO</a></a></li>
        <li><a href="#">Hosting</a></li>
      </ul>
    </li>
    <li><a href="#">Sản phẩm</a></li>
    <li><a href="#">Liên hệ</a></li>
  </ul>
  
</div>

<style type="text/css">
	 #menu ul {
	  background: #8AD385;
	  width: 250px;
	  padding: 0;
	  list-style-type: none;
	  text-align: left;
	}
	#menu li {
	  width: auto;
	  height: 40px;
	  line-height: 40px;
	  border-bottom: 1px solid #e8e8e8;
	  padding: 0 1em;
	}
	#menu li a {
	  text-decoration: none;
	  color: #333;
	  font-weight: bold;
	  display: block;
	}
	#menu li:hover {
	  background: #CDE2CD;
	}
	body {
	 font-family: sans-serif;
	 font-size: 15px;
	}
	#menu ul {
	 background: #8AD385;
	 width: 250px;
	 padding: 0;
	 list-style-type: none;
	 text-align: left;
	}
	#menu li {
	 width: auto;
	 height: 40px;
	 line-height: 40px;
	 border-bottom: 1px solid #e8e8e8;
	 padding: 0 1em;
	}
	#menu li a {
	 text-decoration: none;
	 color: #333;
	 font-weight: bold;
	 display: block;
	}
	#menu li:hover {
	 background: #CDE2CD;
	}
	#menu ul li {
	 position: relative;
	}
	#menu .sub-menu {
	 position: absolute;
	 left: 250px;
	 top: 0;
	}
	#menu .sub-menu {
	 position: absolute;
	 left: 250px;
	 top: 0;
	 display: none;
	}
	#menu li:hover .sub-menu {
	 display: block;
	}

</style>


<footer>Copyright &copy; PhươngTrương</footer>

</div>

</body>
</html>